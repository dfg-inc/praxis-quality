---
id: PREC-XXX
title: ""
roles: [architect]
stages: [plan]
---

## Circumstances

What situation forced a choice?

## Chosen

What was selected.

## Rejected

What was not selected.

## Why

Why the chosen option won.
