---
id: sprint-process
title: Sprint and batch cadence
roles: [ba, architect, developer, quality]
stages: [research, plan, implement, verify]
severity: advisory
overridable: true
sourceDoc: corp-engineering-handbook
sourceVersion: "1.0.0"
---

# Sprint and batch cadence

Prefer work packages that fit one delivery batch (≤ 5 business days of focused engineering). Larger scopes must be decomposed before Architect handoff.

Do not start implementation against a draft vision. Confirm vision once per product surface, then batch change requests into work packages with Definition of Ready.
