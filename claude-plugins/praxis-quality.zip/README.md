# Praxis Quality

Claude UI plugin. Import this ZIP (manifest at archive root).

Primary human workflow: invoke a skill and speak naturally.
Machine runtime: `bin/praxis` (bundled Praxis CLI 0.1.0-alpha.28).
